This program is used to output GameOfLive cell survival with swing GUI.

This program has a lot of changes based on HW1. Due to the requirement to make a Swing GUI, all the parts related to the terminal have been removed. In addition, many functions have been added.
I chose sliders as my main tool for changing grid widths and viewing tick Settings because they are more intuitive and convenient.
Refer to the courseware L09 many GUI usage.
As for how to use the GUI parts are all in the test.pdf introduction