javac ./src/edu/rpi/cs/csci4963/u20/sunj10/hw02/gol/Running.java ./src/edu/rpi/cs/csci4963/u20/sunj10/hw02/gol/Cell.java
javadoc -author -version -d ./docs ./src/edu/rpi/cs/csci4963/u20/sunj10/hw02/gol/Running.java ./src/edu/rpi/cs/csci4963/u20/sunj10/hw02/gol/Cell.java
java src.edu.rpi.cs.csci4963.u20.sunj10.hw02.gol.Running


