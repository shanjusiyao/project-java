package src.edu.rpi.cs.csci4963.u20.sunj10.hw02.gol;
import javax.swing.JPanel;

/**
* code for homework2
* @author Edward Sun
* @version ％I％，％G％
*/

/**
*Cell is extand of Jpanel, with data
* x,y coor,state and livetime 
*/
public class Cell extends JPanel {
    private Boolean state;
    private int x_coor;
    private int y_coor;
    private int livetime;
    
    /**
    * the cell is child function of JPanel
    */
    public Cell(){
        super();
        state = false;
        livetime = 0;
    }
    
    /**
    * set the state with x
    * @param x boolean use to find next state
    */
    public void setState(boolean x){
        state = x; 
        if(x){
            livetime = 1;
        }else{
            livetime = 0;
        }
    }

    /**
    * make this a copy to Cell test 
    * @param test Cell used to copy
    */
    public void Copycell(Cell test){
        state = test.getState();
        x_coor = test.getcoorX();
        y_coor = test.getcoorY();
        livetime = test.getLive();
    }
    
    /**
    * addLive is to change the state and the livetime depand on int x give 
    * @param x input int
    */
    public void addLive(int x){ 
        if(x == 1){
            state = Boolean.TRUE;
            livetime ++;
        }else if (x == 0) {
            if(state){livetime++;}
        }else{
            state = Boolean.FALSE;
            livetime = 0;
        }
    }
    
    /**
    * setCoords is to set the x y coord in cell
    * @param y the int input
    * @param x the int input
    */
    public void setCoords(int y, int x){
        x_coor=x;
        y_coor=y;
    }
    
    //get state
    public boolean getState(){
        return state;
    }

    //get livetime
    public int getLive(){
        return livetime;
    }
    
    //get x_coor
    public int getcoorX(){
        return x_coor;
    }

    //get y_coor
    public int getcoorY(){
        return y_coor;
    }

   
    
}