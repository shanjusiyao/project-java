package src.edu.rpi.cs.csci4963.u20.sunj10.hw02.gol;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.event.*;
import java.beans.*;
import java.io.*;
import javax.swing.filechooser.*;
import javax.swing.filechooser.FileFilter;
import java.nio.file.*;
import java.util.prefs.Preferences;

/**
* code for homework2
* @author Edward Sun
* @version ％I％，％G％
*/

/**
*main() method
*/
public class Running extends JFrame{
    public static void main(String[] args){
        EventQueue.invokeLater(new Runnable()
         {
            public void run()
            {
               MainWindow frame = new MainWindow();
               //make sure the program terminate after window is close.
               frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame.setVisible(true);
            }
         });
    }
}

/**
* The Mainwindow show in this program, basicly include all the botton and slide I need
*/
class MainWindow extends JFrame{
    /**
    * The provate variable start with initialize
    */
    private static int length =15, width =15;
    private static JPanel panel = new JPanel();
    private JPanel westPanel = new JPanel();
    private JPanel southPanel = new JPanel();
    private JButton Start, SpeedUp, Slowdown,Pause;
    private static Cell [][] cell;
    private static Cell [][][] cells= new Cell[25][][];

    /**
    * The mouseHandler use to change the cell state just by clicking
    */
    public mouseHandler handler = new mouseHandler();
    private class mouseHandler implements MouseListener, MouseMotionListener{
        
        public void mouseClicked(MouseEvent event){
            setState(event);
        }
        public void mouseReleased(MouseEvent event){
        }
        public void mousePressed(MouseEvent event){
        }
        public void mouseEntered(MouseEvent event){
        }
        public void mouseExited(MouseEvent event){
        }
        public void mouseDragged(MouseEvent event){
        }
        public void mouseMoved(MouseEvent event){
        }
        public void setState(MouseEvent event){
            Cell t = (Cell)event.getSource();
            if(t.getState()==true){
                t.setState(false);
                event.getComponent().setBackground(Color.WHITE); 
            }
            else{
                t.setState(true);
                event.getComponent().setBackground(cellcolor);
            }
            Savecell(cell);
            event.setSource(t);
        }
            
        
    }
    

    /**
    * Layout the Main screen and divide the area for the toolbar and menu.
    */
    public MainWindow(){
        
        setTitle("Game of Life");

        /**
        * Preference， use this to store all the input 
        * when a user quits the program and then launches it again, 
        * all settings should retain their values as set by the user;
        * if no stored configuration data can be found, use some
        * reasonable program default values
        */
        path = prefs.get("name save", "");
        length = prefs.getInt("row",15);
        width = prefs.getInt("col",15);
        cell = new Cell[length][width];
        Color inlist = cellcolor;
        for(int i= 0; i<10; i++){
            listc[i] = inlist;
            inlist = inlist.darker();
        }
        String temp;
        if(prefs.getBoolean("c", Boolean.FALSE)){
            for(int i = 0; i<cell.length; i++){
                for(int j = 0; j<cell[i].length; j++){
                    cell[i][j] = new Cell();
                    cell[i][j].setCoords(i, j);
                    temp = "c"+ Integer.toString(100*i +j);
                    cell[i][j].setState(prefs.getBoolean(temp, Boolean.TRUE));
                }
            }
        }



        
        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);

        if(prefs.getBoolean("c", Boolean.FALSE)){
            panel.setLayout(new GridLayout(length, width));
            for(int i = 0; i<length; i++){
                for(int j = 0; j<width; j++){
                    cell[i][j].setBorder(BorderFactory.createLineBorder(Color.GRAY));
                    panel.add(cell[i][j]);
                    cell[i][j].addMouseListener(handler);
                }
            }
            DrawGrid(cell, cell);
        }else{
            setGrid(panel, cell, length, width);
        }

        //tool bar part 
        JToolBar bar = new JToolBar();
        bar.setLayout(new BoxLayout(bar, BoxLayout.Y_AXIS));

        JSlider row = new JSlider();
        JSlider col = new JSlider();
        ticknum = new JSlider();
        tick = new JSlider();
        ticknum.setValue(0);

        tick.addChangeListener(new ChangeListener(){
            public void stateChanged(ChangeEvent e) {
                changeticks(e);
            }
        });

        // Slider part with 4 slider added.
        getSlider(bar, row, "row number");
        getSlider(bar, col, "col number");
        getSlider(bar, ticknum, "ticks number");
        tick.setPaintTicks(true);
        tick.setSnapToTicks(true);
        tick.setMajorTickSpacing(20);
        tick.setMinorTickSpacing(5);
        JPanel temps = new JPanel();
        temps.add(tick);
        temps.add(new JLabel("changing ticks"));
        bar.add(temps);


        //button part with 4 botton added
        JButton set = new JButton();
        set.setText("Set Grid");
        set.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent r) {
                if(row.getValue() != 0 && col.getValue()!= 0){
                    prefs.putInt("row", row.getValue()/4);
                    prefs.putInt("col", col.getValue()/4);
                    length = row.getValue()/4;
                    width = col.getValue()/4;
                    cell = new Cell[length][width];
                    setGrid(panel, cell, row.getValue()/4, col.getValue()/4);
                    cells = new Cell[ticknum.getValue()/4+1][length][width];
                    Errortable("Success Resize the Grid\n");
                    panel.updateUI();
                }else{
                    Errortable("The col or row can't be 0\n");
                }
            }
        });

        JButton value = new JButton();
        value.setText("Show Value");
        value.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showValue(e);
            }
        });

        JButton run = new JButton();
        run.setText("Start Process");
        run.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                StartProcess(evt);
            }
        });

        JButton color = new JButton("change color");
        color.addActionListener(new ccellcolor());
        

        JPanel ubar = new JPanel();
        


        ubar.add(set);
        ubar.add(value);
        ubar.add(run);
        ubar.add(color);
        bar.add(ubar);

        ubar = new JPanel();
        JLabel ask = new JLabel("Put in pre outname");
        outputname = new JTextField(15);
        JButton comf = new JButton("Confirm");
        comf.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                path = outputname.getText();
                prefs.put("name save", path);
            }
        });
        ubar.add(ask);
        ubar.add(outputname);
        ubar.add(comf);
        bar.add(ubar);
       
        add(bar, BorderLayout.EAST);

        //Menu part, add open, save, saveALL with unique Hotkey
        JMenuBar menu = new JMenuBar();
        setJMenuBar(menu);
        JMenu file = new JMenu("File");
        menu.add(file);
        
        JMenuItem openItem = new JMenuItem("Open");
        openItem.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
        file.add(openItem);
        openItem.addActionListener(new FileOpenListener());

        JMenuItem saveItem = new JMenuItem("Save");
        saveItem.setAccelerator(KeyStroke.getKeyStroke("ctrl S"));
        file.add(saveItem);
        saveItem.addActionListener(new FileSaveListener());

        JMenuItem saveAllItem = new JMenuItem("Save All");
        saveAllItem.setAccelerator(KeyStroke.getKeyStroke("ctrl D"));
        file.add(saveAllItem);
        saveAllItem.addActionListener(new FileSaveAllListener());

        file.addSeparator();
        JMenuItem exitItem = new JMenuItem("Exit");
        file.add(exitItem);
        exitItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
               System.exit(0);
            }
        });


        chooser = new JFileChooser();


    }

    // a privte fucntion to show all the value about die and live cell, and compare them wtih previous
    private void showValue(ActionEvent e) 
    {
        int live = 0;
        int diff = 0;
        String output;
        for(int i = 0; i<cell.length; i++){
            for(int j = 0; j<cell[i].length; j++){
                if(cell[i][j].getState())live++;
            }
        }
        if( ((int)tick.getValue()*maxtick/100 -1) >= 0 ){
            diff = live;
            for(int i = 0; i<cell.length; i++){
                for(int j = 0; j<cell[i].length; j++){
                    if(cells[(int)tick.getValue()*maxtick/100 -1][i][j].getState())diff--;
                }
            }
            output = diff + " is the the difference in the number of alive cells as compared to the previous" ;
        }else{
            output = "there is no previous data to compare";
        }
        JOptionPane.showMessageDialog(null, "Value of living cells is " + live + "\n The dead cell number is " +
                (width*length-live) + "\n " +
                output);
    }

    // a simple Errortable, just jump out and give massage when error occur.
    private void Errortable(String error) 
    {
        JOptionPane.showMessageDialog(null, error +"\n ");
    }

    // a class to deal with color, with color table and getSelectionModel, also to deal with dark for long 
    //live cell i use darker();
    private class ccellcolor implements ActionListener
   {
        public ccellcolor()
        {
            chooser = new JColorChooser();
            chooser.getSelectionModel().addChangeListener(new ChangeListener()
            {
                public void stateChanged(ChangeEvent event)
                {
                    cellcolor = chooser.getColor();
                    Color temp = cellcolor;
                    for(int i= 0; i<10; i++){
                        listc[i] = temp;
                        temp = temp.darker();
                    }
                    DrawGrid(cell, cell);
                }
            });
            dialog = new JDialog((Frame) null, false);
            dialog.add(chooser);
            dialog.pack();
        }
        //give a visable small window to select color
        public void actionPerformed(ActionEvent event)
        {
            chooser.setColor(getBackground());
            dialog.setVisible(true);
        }

        private JDialog dialog;
        private JColorChooser chooser;
   }

   // a function with botton event will start process the game when the botton is click
    private void StartProcess(ActionEvent evt){
        int times = 0;
        cells = new Cell[ticknum.getValue()/4+1][length][width];
        for(int i = 0; i<cell.length; i++){
            for(int j = 0; j<cell[i].length; j++){
                cells[0][i][j] = new Cell();
                cells[0][i][j].Copycell(cell[i][j]);
            }
        }
        while(times < ticknum.getValue()/4){
            times++;
            for(int i = 0; i<cell.length; i++){
                for(int j = 0; j<cell[i].length; j++){
                    cells[times][i][j] = new Cell();
                    cells[times][i][j].Copycell(cells[times-1][i][j]);
                    cells[times][i][j].addLive(LiveOrDie(cells[times-1],i, j));
                }
            }
        }
        maxtick = times;
        tick.setValue(0);
    }

    // the slide event with Make sure that as you slide the slider (which represents tick)
    // the cell's state changes accordingly
    private void changeticks(ChangeEvent e){
        if(tick.getValueIsAdjusting()){
            int num = (int)tick.getValue()*maxtick/100;
            DrawGrid(cells[num], cell);
            Savecell(cell);
        }
    }

    //The private save fucntion to saveall the ticker we get with a given name + tick number.
    private class FileSaveAllListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            int outputnum;
            for(outputnum = 0; outputnum <= maxtick; outputnum++){
                try
                {
                    Path outFilePath = Paths.get(path+ outputnum +".txt");
                    File outFile = new File(path+ outputnum +".txt");
                    if (Files.exists(outFilePath)) {
                        System.out.printf("Output file %s already exists, has the length of " +
                        "%d, and will be overwritten\n",
                        outFile.getCanonicalPath(), outFile.length());
                    }
                    var fw = new FileWriter(path+ outputnum +".txt");
                    BufferedWriter bf = new BufferedWriter(fw);
                    bf.write(length+", "+width+"\n");
                    for(int i = 0; i< cell.length; i++){
                        for(int j = 0; j< cell[i].length; j++){
                            int txt = 0;
                            if(cells[outputnum][i][j].getState()){
                                txt = 1;
                            }
                            if(j == (cell[i].length-1)){
                                bf.write(txt+"\n");
                            }else{
                                bf.write(txt+", ");
                            }
                        }
                    }
                    bf.close();
                    fw.close();         
                }catch (HeadlessException | IOException e) {
                    JOptionPane.showMessageDialog(MainWindow.this, "Error: IO");
                }
            }
            Errortable("Success Save All the txt file");

        }
    }

    //Only save the cell map you see, not the other. 
    private class FileSaveListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            try
            {
                int outputnum = (int)tick.getValue()*maxtick/100;
                Path outFilePath = Paths.get(path+ outputnum +".txt");
                File outFile = new File(path+ outputnum +".txt");
                if (Files.exists(outFilePath)) {
                    System.out.printf("Output file %s already exists, has the length of " +
                    "%d, and will be overwritten\n",
                    outFile.getCanonicalPath(), outFile.length());
                }
                var fw = new FileWriter(path+ outputnum +".txt");
                BufferedWriter bf = new BufferedWriter(fw);
                bf.write(length+", "+width+"\n");
                for(int i = 0; i< cell.length; i++){
                    for(int j = 0; j< cell[i].length; j++){
                        int txt = 0;
                        if(cell[i][j].getState()){
                            txt = 1;
                        }
                        if(j == (cell[i].length-1)){
                            bf.write(txt+"\n");
                        }else{
                            bf.write(txt+", ");
                        }
                    }
                }
                bf.close();
                fw.close();  
                Errortable("Success Save the txt file");       
            }catch (HeadlessException | IOException e) {
                JOptionPane.showMessageDialog(MainWindow.this, "Error: IO");
            }

        }
    }

    //The private class that the file opens refers to the content of the class, and the PNG is replaced by TXT.
    private class FileOpenListener implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            try {
                FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
                chooser.setFileFilter(filter);
                if (chooser.showOpenDialog(MainWindow.this) == JFileChooser.APPROVE_OPTION) {
                    File f = chooser.getSelectedFile();
                    FileReader fr = new FileReader(f);
                    BufferedReader br = new BufferedReader(fr);
                    String line = br.readLine();
                    String[] start = line.split(", ");
                    length = Integer.parseInt(start[0]);
                    width = Integer.parseInt(start[1]);
                    cell = new Cell[length][width];
                    String[][] map = new String[length][width];
                    
                    int i = 0;int j = 0;
                    while((line = br.readLine()) != null && i!= Integer.parseInt(start[0])) {
                        if (line.length() != Integer.parseInt(start[1])*3-2){
                            Errortable("Input don't match");
                            return;
                        }
                        map[i] = line.split(", ");
                        i++;
                    }

                    if ((line = br.readLine()) != null || i!= Integer.parseInt(start[0])){
                        Errortable("Input don't match");
                        return;
                    }
                    fr.close();
                    br.close();

                    mouseHandler handler = new mouseHandler();
                    setGrid(panel, cell, length, width);
                    panel.updateUI();
                    ticknum.setValue(0);

                    for(i = 0; i<map.length; i++){
                        for(j = 0; j<map[i].length; j++){
                            cell[i][j].setState(Integer.parseInt(map[i][j])==1);
                            if(Integer.parseInt(map[i][j])==1){
                                cell[i][j].setBackground(cellcolor);
                            }else{
                                cell[i][j].setBackground(Color.WHITE);
                            }
                        }
                    }
                    panel.updateUI();
                }
            } catch (HeadlessException | IOException e) {
                JOptionPane.showMessageDialog(MainWindow.this, "Error: IO");
            }
        }
    }
    /**
    * the method use to set a clean Grid in window, with row and col given
    * @param test The drawmap, which show on mainwindow
    * @param cell The 2D cell array use to store the cell data for process
    * @param row The number of row of the Grid need to have
    * @param col The number of col of the Grid need to have
    */
    public void setGrid(JPanel test, Cell[][] cell, int row, int col)
    {
        test.removeAll();
        test.setLayout(new GridLayout(row,col));
        for(int i = 0; i<row; i++){
            for(int j = 0; j<col; j++){
                cell[i][j] = new Cell();
                cell[i][j].setCoords(i, j);
                cell[i][j].setState(false);
                cell[i][j].setBorder(BorderFactory.createLineBorder(Color.GRAY));
                test.add(cell[i][j]);
                cell[i][j].addMouseListener(handler);
            }
        }
        Savecell(cell);
    }

    /**
    * a function use to make a JSlider with SnapToTicks and 0 - 25 lableTable 
    * @param bar a JToolBar use to put in the JSlider the function made
    * @param tick The tick with New properties need to be added
    * @param name The name of the slider need to put in the JPanel
    */
    public void getSlider(JToolBar bar, JSlider tick, String name){
        tick.setPaintTicks(true);
        tick.setSnapToTicks(true);
        tick.setPaintLabels(true);
        tick.setMajorTickSpacing(20);
        tick.setMinorTickSpacing(5);

        Dictionary<Integer, Component> labelTable = new Hashtable<Integer, Component>();
        labelTable.put(0, new JLabel("0"));
        labelTable.put(20, new JLabel("5"));
        labelTable.put(40, new JLabel("10"));
        labelTable.put(60, new JLabel("15"));
        labelTable.put(80, new JLabel("20"));
        labelTable.put(100, new JLabel("25"));
        tick.setLabelTable(labelTable);
        JPanel slider = new JPanel();
        slider.add(tick);
        slider.add(new JLabel(name));
        bar.add(slider);
    }

    /**
    * Take the darker color list to listc 
    * @param time the int time is the livetime of the cell
    * @return Color back to use in the above function
    */
    public Color getdarker(int time){
        if(time >= 10){
            return listc[9];
        }
        return listc[time-1];
    }

    /**
    * Savecell is to savethe cell data in cell to prefs, after the change of the grid 
    * @param cell the 2d array of the cell
    */
    public void Savecell(Cell[][] cell){
        String temp = "c";
        prefs.putBoolean(temp, Boolean.TRUE);
        for(int i = 0; i<cell.length; i++){
            for(int j = 0; j<cell[i].length; j++){
                temp = "c"+ Integer.toString(100*i +j);
                prefs.putBoolean(temp, cell[i][j].getState());
            }
        }
    }

    /**
    * a draw function to draw the gird with given data and refresh the grid  
    * @param cells the 2d array of the cell in a 3d array take the data
    * @param cell the 2d array of the cell need to use to change
    */
    public void DrawGrid(Cell[][] cells, Cell[][] cell){
        for(int i = 0; i<cells.length; i++){
            for(int j = 0; j<cells[i].length; j++){
                if(cells[i][j].getState()){
                    cell[i][j].setBackground(getdarker(cells[i][j].getLive()));
                    cell[i][j].Copycell(cells[i][j]);
                }else{
                    cell[i][j].setBackground(Color.WHITE);
                    cell[i][j].Copycell(cells[i][j]);
                }
            }
        }
    }

    /**
    * method to find of whether the cell in give coordinate will dead or live
    * @param map - the in put map file of all the pre state of the cell
    * @param li - the x coordinate of the cell need to check
    * @param ro - the y coordinate of the cell need to check
    * @return -1,if the cell is going to die, 1 if cell is going to reborn, 
    * 0 if cell is going to stay the same 
    */
    public static int LiveOrDie(Cell[][] cell, int li, int ro){
        int num = 0;
        for (int i = -1; i < 2; i++){
            int fri = li + i;
            if(fri == -1){fri = cell.length-1;}
            else if(fri == cell.length){fri = 0;}
            for (int j = -1; j < 2; j++) {
                int sec = ro + j;
                if(sec == -1){sec = cell[0].length-1;}
                else if(sec ==cell[0].length){sec = 0;}
                if(cell[fri][sec].getState()){num++;} 
            }
        }
        if(cell[li][ro].getState()){num--;} 
        if (num<2 ||num >3){
            return -1;
        }else if(num == 3){
            return 1;
        }
        return 0;
    }



    public static final int DEFAULT_WIDTH = 850;
    public static final int DEFAULT_HEIGHT = 500;
    private int maxtick = 0;
    private JFileChooser chooser;
    private JSlider ticknum;
    private JSlider tick; 
    private Color cellcolor = Color.RED;
    private static Color[] listc = new Color[10];
    private JTextField outputname;
    private String path = "";
    private int ticknow;
    //take prefs save data for next open 
    private Preferences prefs = Preferences.userNodeForPackage(src.edu.rpi.cs.csci4963.u20.sunj10.hw02.gol.Running.class);



}