package src.edu.rpi.cs.csci4963.u20.sunj10.hw01.gol;
import java.time.Clock;
import java.util.*;
import java.io.*;
import java.nio.file.*;
/**
* code for homework1
* @author Edward Sun
* @version ％I％，％G％
*/

public class GameOfLive
{
	/**
	* method to find of whether the cell in give coordinate will dead or live
	* @param map - the in put map file of all the pre state of the cell
	* @param li - the x coordinate of the cell need to check
	* @param ro - the y coordinate of the cell need to check
	* @return -1,if the cell is going to die, 1 if cell is going to reborn, 
	* 0 if cell is going to stay the same 
	*/
	public static int LiveOrDie(String[][] map, int li, int ro){
		int num = 0;
		for (int i = -1; i < 2; i++){
			int fri = li + i;
            if(fri == -1){fri = map.length-1;}
			else if(fri == map.length){fri = 0;}
            for (int j = -1; j < 2; j++) {
                int sec = ro + j;
            	if(sec == -1){sec = map[0].length-1;}
				else if(sec ==map[0].length){sec = 0;}
                num += Integer.parseInt(map[fri][sec]); 
            }
        }
        num -= Integer.parseInt(map[li][ro]);
        if (num<2 ||num >3){
        	return -1;
        }else if(num == 3){
        	return 1;
        }
        return 0;
	}

	/**
	* method to write the map to the given output file
 	* @param map - the in put map file of all the state of the cell
 	* @param start - the row and col number of the map
 	* @param name - the name need to be add to the out put file
	* @exception IOException If some I/O issue occurred
	*/

	public static void Printmap(String[][] map, String[]start, String name)throws IOException{
		Path outFilePath = Paths.get(name);
      	File outFile = new File(name);
      	if (Files.exists(outFilePath)) {
        	System.out.printf("Output file %s already exists, has the length of " +
        	"%d, and will be overwritten\n",
        	outFile.getCanonicalPath(), outFile.length());
      	}
      	var fw = new FileWriter(name);
      	BufferedWriter bf = new BufferedWriter(fw);
      	bf.write(start[0]+", "+start[1]+"\n");
		for(int i = 0; i< map.length; i++){
			for(int j = 0; j< map[i].length; j++){
				if(j == (map[i].length-1)){
					bf.write(map[i][j]+"\n");
				}else{
					bf.write(map[i][j]+", ");
				}
			}
		}
		bf.close();
		fw.close();

	}
	
	/**
	* main() method
	* @param args - command line arguments
	* @exception FileNotFoundException If file is not found
	* @exception IOException If some I/O issue occurred
	*/
	public static void main(String[] args)throws FileNotFoundException, IOException{ 
		String line;
		//reading in all the input about input filename, number of steps and output filename
		Scanner in = new Scanner(System.in);
		System.out.print("Enter file name: ");
		String path = in.nextLine();
		System.out.print("Enter number of steps: ");
		int step = in.nextInt();
		System.out.print("Enter output name: ");
		String outn= in.next();
		FileReader fr = new FileReader(path);
      	BufferedReader br = new BufferedReader(fr);

      	line = br.readLine();
      	String[] start = line.split(", ");
      	String[][] map = new String[Integer.parseInt(start[0])][Integer.parseInt(start[1])];

      	int i = 0;
      	while((line = br.readLine()) != null && i!= Integer.parseInt(start[0])) {
      		if (line.length() != Integer.parseInt(start[1])*3-2){
      			System.out.println("Input don't match");
      			return;
      		}
      		map[i] = line.split(", ");
      		i++;
      	}
      	
      	//out put the error if input don't match
      	if ((line = br.readLine()) != null || i!= Integer.parseInt(start[0])){
      		System.out. println("Input don't match");
      		return;
      	}
      	fr.close();
      	br.close();
      	
      	int test = 0;
      	String[][] temp =new String[Integer.parseInt(start[0])][Integer.parseInt(start[1])];
      	String[][] brf = new String[Integer.parseInt(start[0])][Integer.parseInt(start[1])];

      	// below is the out put part
      	while(test < step){
      		if(test == 0){
      			for(int j = 0; j< map.length; j++){
      				brf[j] = map[j].clone();
      			}
      		} else{
      			for(int j = 0; j< temp.length; j++){
      				brf[j] = temp[j].clone(); 
      			}
      		}
      		temp = new String[Integer.parseInt(start[0])][Integer.parseInt(start[1])];
      		for(int k = 0; k< brf.length; k++){
				for(int j = 0; j< brf[k].length; j++){
					if(LiveOrDie(brf, k, j) == 1){
						temp[k][j] = "1";
					}else if (LiveOrDie(brf, k, j)== -1){
						temp[k][j] = "0";
					}else{
						temp[k][j] = brf[k][j];
					}
				}
			}
			test++;
			String outname = outn + "_" + Integer.toString(test) + ".txt";
			Printmap(temp,start, outname);
      	}
    }	
}