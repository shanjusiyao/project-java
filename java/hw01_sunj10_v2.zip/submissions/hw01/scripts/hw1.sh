javac ./src/edu/rpi/cs/csci4963/u20/sunj10/hw01/gol/GameOfLive.java
javadoc -author -version -d ./docs ./src/edu/rpi/cs/csci4963/u20/sunj10/hw01/gol/GameOfLive.java
java src.edu.rpi.cs.csci4963.u20.sunj10.hw01.gol.GameOfLive


