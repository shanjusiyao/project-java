This program is used to output GameOfLive cell survival.

You will be asked to enter the name of the file first
"Enter file name: "
It then asks how many files to output (loop through several times)
"Enter number of steps: "
Finally you are asked for the name of the output file
"Enter output name: "

test1 and test2 is the txt seed file use to test program, to test, need to drag it out to the folder hw01.
Please run the.cmd and.sh files in the hW1 directory, otherwise an error will occur.

To run the code;
Put the seed file in the hw01 folder,
terminal:
./scripts/hw1.sh or scripts\hw1.cmd
The output file will also in hw01 folder.