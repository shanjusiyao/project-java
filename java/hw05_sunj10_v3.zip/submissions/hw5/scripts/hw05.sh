javac -cp .:/Users/lilyhaiyodoku/Tomcat/lib/servlet-api.jar
 ./src/edu/rpi/cs/csci4963/u20/sunj10/hw05/farmers_market/*.java
javadoc -author -version -d ./docs ./src/edu/rpi/cs/csci4963/u20/sunj10/hw05/farmers_market/*.java
java src.edu.rpi.cs.csci4963.u20.sunj10.hw05.farmers_market.ListFarmersMarket
