DROP DATABASE IF EXISTS `farmersmarket`;
CREATE SCHEMA `farmersmarket` DEFAULT CHARACTER SET utf8mb4 ;

DROP TABLE IF EXISTS `farmersmarket`.`FarmersMarket`;
CREATE TABLE `farmersmarket`.`FarmersMarket`(
    `FMID` INT,
    `MarketName` VARCHAR(256),
    `Website` VARCHAR(1024) DEFAULT NULL,
    `Facebook` VARCHAR(1024) DEFAULT NULL,
    `Twitter` VARCHAR(256) DEFAULT NULL,
    `Youtube` VARCHAR(1024) DEFAULT NULL,
    `OtherMedia` VARCHAR(1024) DEFAULT NULL,
    `street` VARCHAR(1024) DEFAULT NULL,
    `city` VARCHAR(256) DEFAULT NULL,
    `County` VARCHAR(64) DEFAULT NULL,
    `State` VARCHAR(64) DEFAULT NULL,
    `zip` VARCHAR(125) DEFAULT NULL,
    `Season1Date` VARCHAR(256) DEFAULT NULL,
    `Season1Time` VARCHAR(256) DEFAULT NULL,
    `Season2Date` VARCHAR(256) DEFAULT NULL,
    `Season2Time` VARCHAR(256) DEFAULT NULL,
    `Season3Date` VARCHAR(256) DEFAULT NULL,
    `Season3Time` VARCHAR(256) DEFAULT NULL,
    `Season4Date` VARCHAR(256) DEFAULT NULL,
    `Season4Time` VARCHAR(256) DEFAULT NULL,
    `x` FLOAT,
    `y` FLOAT,
    `Location` VARCHAR(256),
    `Credit` CHAR,
    `WIC` CHAR,
    `WICcash` CHAR,
    `SFMNP` CHAR,
    `SNAP` CHAR,
    `Organic` CHAR,
    `Bakedgoods` CHAR,
    `Cheese` CHAR,
    `Crafts` CHAR,
    `Flowers` CHAR,
    `Eggs` CHAR,
    `Seafood` CHAR,
    `Herbs` CHAR,
    `Vegetables` CHAR,
    `Honey` CHAR,
    `Jams` CHAR,
    `Maple` CHAR,
    `Meat` CHAR,
    `Nursery` CHAR,
    `Nuts` CHAR,
    `Plants` CHAR,
    `Poultry` CHAR,
    `Prepared` CHAR,
    `Soap` CHAR,
    `Trees` CHAR,
    `Wine` CHAR,
    `Coffee` CHAR,
    `Beans` CHAR,
    `Fruits` CHAR,
    `Grains` CHAR,
    `Juices` CHAR,
    `Mushrooms` CHAR,
    `PetFood` CHAR,
    `Tofu` CHAR,
    `WildHarvested` CHAR,
    `updateTime` VARCHAR(64),
    -- MySQL Spatial field
    `latlong` POINT SRID 4326,
    `STAR` INT,
    PRIMARY KEY (`FMID`)
)ENGINE = INNODB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `farmersmarket`.`User`;
CREATE TABLE `farmersmarket`.`User`(
    `UID` INT(11) NOT NULL AUTO_INCREMENT,
    `ScreenName` VARCHAR(32),
    `Password` VARCHAR(256),
    PRIMARY KEY (`UID`)
)ENGINE = INNODB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `farmersmarket`.`Comments`;
CREATE TABLE `farmersmarket`.`Comments`(
    `CID` INT NOT NULL AUTO_INCREMENT,
    `FMID` INT NOT NULL,
    `UID` INT NOT NULL,
    -- 0 star - 5 star
    `STAR` INT,
    `Comments` VARCHAR(256),
    PRIMARY KEY (`CID`)
)ENGINE = INNODB DEFAULT CHARSET=utf8;

/*
LOAD DATA INFILE './Farmers Markets.csv'
    INTO TABLE `farmersmarket`.`FarmersMarket`
    FIELDS TERMINATED BY ','
    OPTIONALLY ENCLOSED BY '"'
    lines terminated by '\r\n'
    ignore 1 lines
    (FMID,MarketName,Website,Facebook,Twitter,Youtube,OtherMedia,street,city,County,State,zip,Season1Date,Season1Time,Season2Date,Season2Time,Season3Date,Season3Time,Season4Date,Season4Time,x,y,Location,Credit,WIC,WICcash,SFMNP,SNAP,Organic,Bakedgoods,Cheese,Crafts,Flowers,Eggs,Seafood,Herbs,Vegetables,Honey,Jams,Maple,Meat,Nursery,Nuts,Plants,Poultry,Prepared,Soap,Trees,Wine,Coffee,Beans,Fruits,Grains,Juices,Mushrooms,PetFood,Tofu,WildHarvested,updateTime);
*/