package src.edu.rpi.cs.csci4963.u20.sunj10.hw05.farmers_market;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import src.edu.rpi.cs.csci4963.u20.rcsid.hw05.farmers_market.ConnDB;
import src.edu.rpi.cs.csci4963.u20.rcsid.hw05.farmers_market.FarmersMarket;

/**
 * Servlet implementation class ListComments
 */
@WebServlet("/ListComments")
public class ListComments extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String DB_USER_URL = "jdbc:mysql://localhost/User?useUnicode=true&characterEncoding=UTF-8";
	private static final String DB_COMMENTS_URL = "jdbc:mysql://localhost/Comments?useUnicode=true&characterEncoding=UTF-8";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListComments() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	public List<Comments> getAllData(int fmid){
		List<Comments> list = new ArrayList<Comments>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		try {
			if(fmid == -1)
				sql = "select * from Comments";
			else
				sql = "select * from Comments where FMID = " + fmid;
			
			conn = ConnDB.getConnection(DB_COMMENTS_URL);
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				Comments com = new Comments();
				
				com.setId(rs.getInt(1));
				com.setFMId(rs.getInt(2));
				// need to replace uid to screen name
				com.setUId(rs.getInt(3));
				com.setStar(rs.getInt(4));
				com.setComments(rs.getString(5));
				list.add(com);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			
			try {
				ConnDB.close(rs);
				ConnDB.close(pstmt);	
				ConnDB.close(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public static void main(String[] args) {		
		List<Comments> list = new ArrayList<Comments>();
		list = new ListComments().getAllData(-1);
		for (Comments com : list) {
			System.out.println(com.getId());
			System.out.println(com.getFMId());
			System.out.println(com.getUId());
			System.out.println(com.getComments());
		}
	}

}
