package src.edu.rpi.cs.csci4963.u20.sunj10.hw05.farmers_market;

public class Comments {
	private int cid;
	private int fmid;
	private int uid;
	private int star;
	private String comments;
	
	public int getId() {
		return cid;
	}
	
	public void setId(int id) {
		this.cid = id;
	}
	
	public int getFMId() {
		return fmid;
	}
	
	public void setFMId(int id) {
		this.fmid = id;
	}
	
	public int getUId() {
		return uid;
	}
	
	public void setUId(int id) {
		this.uid = id;
	}


	public int getStar() {
		return star;
	}
	
	public void setStar(int star) {
		this.star = star;
	}
	
	public String getComments() {
		return comments;
	}
	
	public void setComments(String comments) {
		this.comments = comments;
	}
}
