package src.edu.rpi.cs.csci4963.u20.sunj10.hw05.farmers_market;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnDB {
	private static Connection conn = null;
	private static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	private static final String USER_NAME = "root";
	private static final String PASSWORD = "rootroot"; // replace password
	
	/**
	 * Get Connection
	 * @return Connection
	 */
	public static Connection getConnection(String URL){
		try {
			Class.forName(DRIVER_NAME);
			conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * Close Result Set
	 * @param rs ResultSet
	 * @throws SQLException
	 */
	public static void close(ResultSet rs) throws SQLException{
		if(rs != null){
			rs.close();
			rs = null;
		}
	}
	
	/**
	 * Close PreparedStatement Object
	 * @param pstmt PreparedStatement Object
	 * @throws SQLException
	 */
	public static void close(PreparedStatement pstmt) throws SQLException{
		if(pstmt != null){
			pstmt.close();
			pstmt = null;
		}
	}
	
	/**
	 * Close Connection
	 * @param conn Connection
	 * @throws SQLException
	 */
	public static void close(Connection conn) throws SQLException{
		if(conn != null){
			conn.close();
			conn = null;
		}
	}
	
	/**
	 * Test Database Connection
	 * @param conn Connection
	 * @throws SQLException
	 */
	public static void main(String[] args) {
		String DB_URL = "jdbc:mysql://localhost/FarmersMarket?useUnicode=true&characterEncoding=UTF-8";
		String DB_USER_URL = "jdbc:mysql://localhost/User?useUnicode=true&characterEncoding=UTF-8";
		String DB_COMMENTS_URL = "jdbc:mysql://localhost/Comments?useUnicode=true&characterEncoding=UTF-8";
	    
		System.err.println(getConnection(DB_URL));
		System.err.println(getConnection(DB_USER_URL));
		System.err.println(getConnection(DB_COMMENTS_URL));
	}

}
