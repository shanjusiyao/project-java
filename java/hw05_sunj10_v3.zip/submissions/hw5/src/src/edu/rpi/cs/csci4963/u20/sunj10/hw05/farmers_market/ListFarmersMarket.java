package src.edu.rpi.cs.csci4963.u20.sunj10.hw05.farmers_market;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import src.edu.rpi.cs.csci4963.u20.rcsid.hw05.farmers_market.ConnDB;
import src.edu.rpi.cs.csci4963.u20.rcsid.hw05.farmers_market.FarmersMarket;

/**
 * Servlet implementation class ListFarmersMarket
 */
@WebServlet("/ListFarmersMarket")
public class ListFarmersMarket extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int DATA_PER_PAGE = 10;
	private static final String DB_URL = "jdbc:mysql://localhost/FarmersMarket?useUnicode=true&characterEncoding=UTF-8";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListFarmersMarket() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String cur = (String)request.getParameter("cur");
		String conditions = (String)request.getParameter("conditions");
		List<FarmersMarket> list = new ArrayList<FarmersMarket>();
		list = new ListFarmersMarket().getAllData(Integer.parseInt(cur), conditions);
		int totalPage = new ListFarmersMarket().getTotalPage();
		request.setAttribute("FarmersMarket", list);
		request.setAttribute("TotalPage", totalPage);
		
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
	
	public int getTotalPage(){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int count = 0;
		try {
			sql = "select count(*) from FarmersMarket";
			
			conn = ConnDB.getConnection(DB_URL);
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				count = rs.getInt(1);
			}
			
			count = (int)Math.ceil((count + 1.0 - 1.0) / DATA_PER_PAGE);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			
			try {
				ConnDB.close(rs);
				ConnDB.close(pstmt);	
				ConnDB.close(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return count;
	}
	
	public List<FarmersMarket> getAllData(int cur, String conditions){
		List<FarmersMarket> list = new ArrayList<FarmersMarket>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		try {
			sql = "select * from FarmersMarket";
			if (conditions.length() > 0) {
				sql = sql + "where " + conditions;
			}
			
			conn = ConnDB.getConnection(DB_URL);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (cur - 1) * DATA_PER_PAGE);
			pstmt.setInt(2, DATA_PER_PAGE);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				FarmersMarket fm = new FarmersMarket();
				fm.setId(rs.getInt(1));
				fm.setName(rs.getString(2));
				fm.setWebsite(rs.getString(3));
				fm.setAddress(rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(7));
				list.add(fm);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			
			try {
				ConnDB.close(rs);
				ConnDB.close(pstmt);	
				ConnDB.close(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public static void main(String[] args) {
		System.out.println(new ListFarmersMarket().getTotalPage());
		
		List<FarmersMarket> list = new ArrayList<FarmersMarket>();
		list = new ListFarmersMarket().getAllData(3, "");
		for (FarmersMarket fm : list) {
			System.out.println(fm.getId());
			System.out.println(fm.getName());
			System.out.println(fm.getWebsite());
			System.out.println(fm.getAddress());
		}
	}

}
