build is the place to store class
Webcontent is place to save Web-INF

mysql-8.0.21
mysql-connector-java-8.0.21

apache-tomcat-9.0.37
IDE
Eclipse IDE for Java Developers 2020-06 (4.16.0) Java
 +Eclipse Java EE Developer Tools
+Eclipse Java Web Developer Tools
+Eclipse Web Developer Tools
+Eclipse XML Editors and Tools
+JST Server Adapters
+JST Server Adapters Extentions