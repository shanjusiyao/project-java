Before that I want to declare that this assignment to complete the degree is not 100%. I spent the past week trying to solve the problem, but still failed to catch up。
I tried to finish the networking part, but I ran out of time. 
I divided my homework into six parts
The first part is: Read and organize the file into the Graph class (finished)
The second part is: Three algorithms are used to find the initial infected population (completed).
The third part is: the algorithm is used for each tick (), changing the state of the infected population (complete).
The fourth part is: The algorithm is used for multithreading, and the task is evenly distributed (near completion).
The fifth part is to display all the calculated data on Swing (not started)
The sixth part is: Summarize and make a PDF analysis (not completed)

hope you can take into consideration and give some points.

Thank you.