package src.hw4;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class HThread
{
	public static GraphWrapper ttt = new GraphWrapper("docs/test.csv");
	public static ArrayList<String> chang;/* = new ArrayList<String>();*/
	public static ArrayList<String> chang1;/*= new ArrayList<String>();*/
	public static ArrayList<String> chang2;/* = new ArrayList<String>();*/

	static class running implements Runnable
	{
	   /**
	    * Constructs the runnable.
	    * @aBall the ball to bounce
	    * @aPanel the component in which the ball bounces
	    */
	   public running(ArrayList<String> temp)
	   {
	      this.temp = temp;/*
	      this.chang = chang;
	      this.chang1 = chang1;
	      this.chang2 = chang2;*/
	   }

	   public void run()
	   {
	      try
	      {
	        chang =ttt.Tick(temp,0.7, 2, 0.2, chang, chang1, chang2);
	        /*Iterator<String> r = chang.iterator();
			while(r.hasNext()){
				String h = r.next();
				System.out.println(h);
			}*/
	      }
	      catch (Exception e){}
	   }
	   	private ArrayList<String> temp;
	}
	// the part of get Multiple threads
	public static void addThread(int i, GraphWrapper temp){
		chang = new ArrayList<String>();
		chang1= new ArrayList<String>();
		chang2 = new ArrayList<String>();
		ArrayList<Thread> t = new ArrayList<Thread>();
		
		int c = 0;
		int d = temp.GetGraph().size()/(int)Math.pow(2,i);
		while(c < Math.pow(2,i)){
			ArrayList<String> txt = new ArrayList<String>();
			if(c+1 == Math.pow(2,i)){
				txt.addAll(temp.GetGraph().subList(c*d, temp.GetGraph().size()));
				//System.out.println(c*d+":"+temp.GetGraph().size());
			}else{
				txt.addAll(temp.GetGraph().subList(c*d, c*d+d));
				//System.out.println(c*d+":"+((c*d)+d));
			}


			/*
			Iterator<String> r = txt.iterator();
			while(r.hasNext()){
				String h = r.next();
				System.out.println(h+":"+ttt.GetMap().get(h).Getstate());
			}*/
			Runnable test = new running(txt);
			t.add(new Thread(test));
			c++;
		}
		Iterator<Thread> a = t.iterator();
		while(a.hasNext()){
			a.next().start();
			//a.next().join();
		}
		while(a.hasNext()){
			try{
				a.next().join();
			}
	      	catch (InterruptedException e){}
		}
		ttt.Tickchange(chang,1);
		ttt.Tickchange(chang1,-1);
		ttt.Tickchange(chang2,-2);
		Iterator<String> dats = ttt.GetGraph().iterator();
		while(dats.hasNext()){
			String h = dats.next();
			System.out.println(h+":"+ttt.GetMap().get(h).Getstate());
		}
	}
	public static void main(String[] arg){
		ttt.BFSpick(10);
		addThread(0, ttt);
		addThread(0, ttt);

	}

}




