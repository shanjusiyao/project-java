package src.hw4;
/**
*Edge use to store child and parent
*/
public class Edge<N>{
	private N parent;
	private N child;
	
	public Edge(N parent, N child) {
		this.parent = parent;
		this.child = child;
	}
	public N g_parent(){
		return parent;
	}
	public N g_child() {
		return child;
	}
}
