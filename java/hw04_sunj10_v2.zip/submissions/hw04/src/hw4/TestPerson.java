package src.hw4;
/**
*The class use to get testperson as node
*/
public class TestPerson{
	private String name;
	private int state;
	public TestPerson(){
		this.name = "";
		this.state = 0;
	}

	public TestPerson(String name, int s){
		this.name = name;
		this.state = s;
	}

	public void Cstate(int chg){
		this.state = chg;
	}

	public String Getname(){
		return this.name;
	}

	public int Getstate(){
		return this.state;
	}

	public int compareTo(TestPerson cmp) {
		return this.state - cmp.Getstate();
	}
	
	public boolean equals(TestPerson input) {
		System.out.println(name +" "+ input.name);
		return this.name.equals(input.name);

	}
}