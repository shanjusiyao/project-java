package src.hw4;

import java.util.*;
import java.io.*;

public class Parser {

	/** 
    * @param filename The path to the "CSV" file that contains the pairs                                                                                                
    * @param data The Map that stores parsed pairs;usually an empty Map
    * @param temp The Graph that stores parsed characters; usually an empty Set.
    * @throws IOException if file cannot be read of file not a CSV file                                                                                     
	*/
    public static void readData(String filename, Graph<String> temp, Map<String, TestPerson>data ) 
    		throws IOException {

    	BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line = null;

        while ((line = reader.readLine()) != null) {
             int i = line.indexOf("\",\"");
             if ((i == -1) || (line.charAt(0)!='\"') || (line.charAt(line.length()-1)!='\"')) {
            	 throw new IOException(filename+" goes wrong");
             }             
             String node1 = line.substring(1,i);
             String node2 = line.substring(i+3,line.length()-1);
             
             temp.node_add(node1);
             temp.node_add(node2);
             if(!data.containsKey(node1)){
                data.put(node1,new TestPerson(node1, 0));
             }
             if(!data.containsKey(node2)){
                data.put(node2,new TestPerson(node2, 0));
             }
             temp.edge_add(node1,node2);
             temp.edge_add(node2,node1);

        }
    }
    
}
