package src.hw4;
import java.util.*;
import java.io.*;

public class GraphWrapper {
	public static Graph<String> temp;
	public static HashMap<String, TestPerson> data;

	public GraphWrapper(String f){
		this.temp = new Graph<String>();
		this.data = new HashMap<String, TestPerson>();
		try{
			Parser.readData(f,temp,data);
		}catch(IOException e){
			throw new RuntimeException("Input Filename can't be used");
		}
	}


	public static ArrayList<String> GetGraph(){
		ArrayList<String> ts = new ArrayList<String>();
		ts.addAll(temp.SetNodes());
		return ts;
	}

	public static HashMap<String, TestPerson> GetMap(){
		return data;
	}
	/**
	* @param size this int use to get random number
	* @return random 
	* get a random number in range size
	*/
	public static int randoms(int size){
		double test = Math.random();
		return (int)(test*size);
	}

	/**
	* @param n this num is use to show how many infect person will be pick randomly at begaining 
	*/
	public static void randompick(int n){
		List<String> text = new ArrayList<String>();
		text.addAll(data.keySet());
		int size = text.size();
		int i;
		int pick;
		ArrayList<Integer> ran = new ArrayList<Integer>();
		for(i =0; i< n; i++){
			pick = randoms(size);
			while(ran.contains(pick)){
				pick = randoms(size);
			}
			data.get(text.get(pick)).Cstate(1);
			ran.add(pick);
		}
	}

	/**
	* @param n this num is use to show any person with more than n degrees will be pick 
	*/
	public static void degreepick(int n){
		Iterator<String> dat = data.keySet().iterator();
		while(dat.hasNext()){
			String t = dat.next();
			if(temp.GetArray(t).size() > n){
				data.get(t).Cstate(1);
			}
		}
	}

	/**
	* @param n this num is use to show the max number of infected person pick by BFS
	* if n is larger than max person, all the person will be infected
	*/
	public static void BFSpick(int n){
		List<String> text = new ArrayList<String>();
		text.addAll(data.keySet());
		int pick = randoms(text.size());
		//System.out.println(pick);
		String fir = text.get(pick);
		text = new ArrayList<String>();
		text.add(fir);
		int add = 0;
		while(text.size()!=0 && add < n){
			String t = text.remove(0);
			Iterator<Edge<String>> te = temp.GetArray(t).iterator();
			while(te.hasNext()&&add<n){
				t = te.next().g_child();
				if(!text.contains(t)&&data.get(t).Getstate()!=1){
					add++;
					data.get(t).Cstate(1);
					text.add(t);
				}
			}  
		}
	}

	/**
	* @param text the name of the person is picked in this thread 
	* @param lamd the lamda use to determine how many person will go infect this tick
	* @param time the time of dead or cure(path this time the infected person will be either dead or cure)
	* @param deadornot the rate of infected person go die
	* @param change the name of the person go infected after this tick
	* @param change1 the name of the person go dead after this tick
	* @param change2 the name of the person go cure after this tick
	* @return change the name of the person go infected after this tick
	*/
	public static ArrayList<String> Tick(ArrayList<String> text, double lamd, int time, double deadornot,ArrayList<String> change, ArrayList<String> change1, ArrayList<String> change2 ){
		//ArrayList<String> change = new ArrayList<String>();
		int size = text.size();
		int i;
		int infect = 0;
		int nw = 0;
		//List<String> out = new ArrayList<String>();
		for(i = 0; i<size; i++){
			if(data.get(text.get(i)).Getstate()>0){
				infect++;
				int temps = (int)Math.round(lamd*infect)-nw;
				Iterator<Edge<String>> te =temp.GetArray(text.get(i)).iterator();
				while(temps > 0 && te.hasNext()){
					String g = te.next().g_child();
					if(data.get(g).Getstate()==0 && !change.contains(g)){
						change.add(g);
						nw++;
						temps--;
					}
				}
				if(data.get(text.get(i)).Getstate() == time){
					double test = Math.random();
					if(test < deadornot ){
						change1.add(text.get(i));
						//usedata.get(text.get(i)).Cstate(-1);
					}else{
						change2.add(text.get(i));
						//usedata.get(text.get(i)).Cstate(-2);
					}
				}else{
					change.add(text.get(i));
				}
			}
		}
		return change;
	}

	public static void Tickchange(ArrayList<String> change, int state){
		int i;
		if(state == 1){
			for(i=0; i< change.size(); i++){
				data.get(change.get(i)).Cstate(data.get(change.get(i)).Getstate()+1);
			}
		}else if(state == -1){
			for(i=0; i< change.size(); i++){
				data.get(change.get(i)).Cstate(-1);
			}
		}else{
			for(i=0; i< change.size(); i++){
				data.get(change.get(i)).Cstate(-2);
			}
		}
		change.clear();
	}

/*my test step
	public static void main(String[] arg){
		//Graph<String> test;
		String file = "test.csv";
		temp = new Graph<String>();
		data = new HashMap<String, TestPerson>();
		//Set<String> chars = new HashSet<String>();
		try{
			Parser.readData(file,temp,data);
		}catch(IOException e){
			throw new RuntimeException("Input Filename can't be used");
		}

		
		Iterator<String> dats = data.keySet().iterator();
		while(dats.hasNext()) {
			String t = dats.next();
			System.out.print(t+":");
			if(temp.GetArray(t)!= null){
				Iterator<Edge<String>> te = temp.GetArray(t).iterator();
				while(te.hasNext()){
					System.out.print(te.next().g_child()+" ");
				}
			}
			System.out.println("");
		}

		//randompick(5);
		//degreepick(5);
		BFSpick(10);
		Iterator<String> dat = data.keySet().iterator();
		while(dat.hasNext()){
			String t = dat.next();
			if(data.get(t).Getstate() == 1){
				System.out.println(t+":"+data.get(t).Getstate());
			}
		}
		System.out.println("");
		
		ArrayList<String> change = new ArrayList<String>();
		ArrayList<String> change1 = new ArrayList<String>();
		ArrayList<String> change2 = new ArrayList<String>();
		int x = 5;
		while(x!=0){
			ArrayList<String> c = new ArrayList<String>();
			c.addAll(data.keySet());
			change = Tick(c, 0.7, 2, 0.2, change1, change2);
			Tickchange(change,1);
			Tickchange(change1,-1);
			Tickchange(change2,-2);
			x--;
		}
		Iterator<String> dats = data.keySet().iterator();
		while(dats.hasNext()){
			String t = dats.next();
			System.out.println(t+":"+data.get(t).Getstate());
		}

	}*/

}