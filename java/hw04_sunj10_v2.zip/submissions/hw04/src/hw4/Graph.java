package src.hw4;
import java.util.*;

public class Graph <N>{
	private HashMap<N,ArrayList<Edge<N>> >node_list = new HashMap<N, ArrayList<Edge<N>> >();
	
	public Graph() 
	{
		this.node_list = new HashMap<N, ArrayList<Edge<N>> >();
	}
	
	/**
	* @param add, can be any class ,just add node
	*/
	public void node_add(N add) {
		if (!this.node_list.containsKey(add))
		{
			this.node_list.put(add, new ArrayList<Edge<N>>());
		}
	}
	/**
	* @param parent can be any class ,just add node to edge
	* @param child can be any class ,just add node to edge
	*use edge_add not Addedge in order to distinguish between graph and graphwrapper's functions
	*/
	public void edge_add(N parent, N child) {
		if(this.node_list.containsKey(parent)){
			if(this.node_list.containsKey(child)){
				this.node_list.get(parent).add(new Edge<N>(parent,child));
			}
		}
	}
	/**
	* @return this.node_list.keySet(); the set of all the key
	*/
	public Set<N> SetNodes()
	{
		return this.node_list.keySet();
	}
	/**
	* @param test can be any class 
	* @return node_list.get(test); the set of all the list
	*/
	public ArrayList<Edge<N>> GetArray(N test){
		return node_list.get(test);
	}

}