javac ./src/hw4/GraphWrapper.java ./src/hw4/Edge.java ./src/hw4/TestPerson.java ./src/hw4/Graph.java ./src/hw4/Parser.java ./src/hw4/HThread.java
javadoc -author -version -d docs ./src/hw4/GraphWrapper.java ./src/hw4/Edge.java ./src/hw4/TestPerson.java ./src/hw4/Graph.java ./src/hw4/Parser.java ./src/hw4/HThread.java
java src.hw4.HThread


