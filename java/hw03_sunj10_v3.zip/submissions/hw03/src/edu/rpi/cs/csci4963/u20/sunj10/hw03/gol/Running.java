package src.edu.rpi.cs.csci4963.u20.sunj10.hw03.gol;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.event.*;
import java.beans.*;
import java.io.*;
import javax.swing.filechooser.*;
import javax.swing.filechooser.FileFilter;
import java.nio.file.*;
import java.util.prefs.Preferences;

/**
* code for homework3
* @author Edward Sun
* @version ％I％，％G％
*/

/**
*main() method
*/
public class Running extends JFrame{
    public static void main(String[] args){
        EventQueue.invokeLater(new Runnable()
         {
            public void run()
            {
               MainWindow frame = new MainWindow();
               frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               frame.setVisible(true);
            }
         });
    }
}

/**
* The Mainwindow show in this program, basicly include all the botton and slide I need
*/
class MainWindow extends JFrame{
    /**
    * The provate variable start with initialize
    */

    private static Boolean test = true;
    private static int length =10, width =10;
    private static JPanel panel = new JPanel();
    private JPanel westPanel = new JPanel();
    private JPanel southPanel = new JPanel();
    private JButton Start, SpeedUp, Slowdown,Pause;
    private static Cell [][] cell;
    private static Boolean connected = Boolean.FALSE;
    ///private static Cell [][][] cells = new Cell[25][][];
    private static Boolean setgame = Boolean.TRUE;
    private static Boolean mousestate = false; 
    private static int shiptyp = 2;
    private static int [] shipnum = new int[10];
    private static int boot_id = 1;
    private static int score = 0;
    private static int shootnum = 5;
 
    /**
    * The mouseHandler use to change the cell state just by clicking
    */
    public mouseHandler handler = new mouseHandler();
    private class mouseHandler implements MouseListener, MouseMotionListener{
        
        public void mouseClicked(MouseEvent event){
            setState(event);
        }
        public void mouseReleased(MouseEvent event){
        }
        public void mousePressed(MouseEvent event){
        }
        public void mouseEntered(MouseEvent event){
        }
        public void mouseExited(MouseEvent event){
        }
        public void mouseDragged(MouseEvent event){
        }
        public void mouseMoved(MouseEvent event){
        }
        public void setState(MouseEvent event){
            Cell t = (Cell)event.getSource();
            if(setgame){
                int i;
                int x = t.getcoorX();
                int y = t.getcoorY();
                Boolean can_put = true;
                shiptyp = sizebot.getValue()/25 + 1;
                if(!(t.getboot())){
                    if(mousestate){
                        if((x + shiptyp) > width || shiptyp == 0 || shipnum[shiptyp-1] < 1){
                            Errortable("ERROR: You can't put this ship here");
                        }else{
                            for(i = 0; i < shiptyp; i++){
                                if(cell[y][x+i].getboot()){
                                    Errortable("ERROR: You can't put you ship here");
                                    can_put = Boolean.FALSE;
                                    break;
                                }
                            }
                            if(can_put){
                                for(i = 0; i < shiptyp; i++){
                                    cell[y][x+i].setboot(shiptyp*1000 + boot_id);
                                    cell[y][x+i].setBackground(cellcolor);
                                }
                                boot_id++;
                                shipnum[shiptyp-1]--;
                            }
                        }
                    }else{
                        if((y + shiptyp) > length || shiptyp == 0 || shipnum[shiptyp-1] < 1){
                            Errortable("ERROR: You can't put you ship here");
                        }else{
                            for(i = 0; i < shiptyp; i++){
                                if(cell[y+i][x].getboot()){
                                    Errortable("ERROR: You can't put you ship here");
                                    can_put = Boolean.FALSE;
                                    break;
                                }
                            }
                            if(can_put){
                                for(i = 0; i < shiptyp; i++){
                                    cell[y+i][x].setboot(shiptyp*1000 + boot_id);
                                    cell[y+i][x].setBackground(cellcolor);
                                }
                                boot_id++;
                                shipnum[shiptyp-1]--;
                            }
                        }
                    }
                }else{
                    if(t.havebotid()){
                        int id = t.getbotid();
                        shipnum[id/1000-1]++;
                        int j;
                        for(i = 0; i < length; i++){
                            for(j = 0; j < width; j++){
                                if(cell[i][j].getbotid() == id){
                                    cell[i][j].deletebot();
                                    cell[i][j].setBackground(Color.BLUE);
                                }
                            }
                        }
                    }else{
                        Errortable("ERROR: something wrong in the code of deleteboot");
                    }

                }
            }else{
                int shipidc = t.hitboot();
                t.deletebot();
                if(shipidc != -1){
                    event.getComponent().setBackground(Color.RED);
                    int i;int j; 
                    Boolean shipfall = Boolean.TRUE;  
                    for(i = 0; i < length; i++){
                        for(j = 0; j < width; j++){
                            if(cell[i][j].getbotid() == shipidc){
                                shipfall = Boolean.FALSE;
                            }
                        }
                    }
                    if(shipfall){
                        Errortable("you sinking a ship with length " + Integer.toString(shipidc/1000));
                        if(wingame(cell)){
                            Errortable("you win this game");
                            score++;
                        }
                    }
                }else{
                    event.getComponent().setBackground(Color.BLACK);
                }
            }
            //Savecell(cell);
            panel.updateUI();
            event.setSource(t);
        }
        
    }
    

    /**
    * Layout the Main screen and divide the area for the toolbar and menu.
    */
    public MainWindow(){
        
        setTitle("Battle Ship Game");

        /**
        * Preference， use this to store all the input 
        * when a user quits the program and then launches it again, 
        * all settings should retain their values as set by the user;
        * if no stored configuration data can be found, use some
        * reasonable program default values
        */
        

        cell = new Cell[length][width];
        Color inlist = cellcolor;
        shipnum = set_shipnumber(shipnum);
        //System.out.println(shipnum[2]);

        for(int i = 0; i<cell.length; i++){
            for(int j = 0; j<cell[i].length; j++){
                cell[i][j] = new Cell();
                cell[i][j].setCoords(i, j);
            }
        }

        setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);

        panel.setLayout(new GridLayout(length, width));
        for(int i = 0; i<length; i++){
            for(int j = 0; j<width; j++){
                cell[i][j].setBorder(BorderFactory.createLineBorder(Color.WHITE));
                panel.add(cell[i][j]);
                cell[i][j].addMouseListener(handler);
            }
        }
        DrawGrid(cell, cell);


        JToolBar bar = new JToolBar();
        bar.setLayout(new BoxLayout(bar, BoxLayout.Y_AXIS));

        JSlider row = new JSlider();
        JSlider col = new JSlider();
        sizebot = new JSlider();

        
        getSlider(bar, row, "row number");
        getSlider(bar, col, "col number");
        getSlider25(bar, sizebot, "botchoose to put");

        JButton relat = new JButton();
        relat.setText("Hor or Vrt");
        relat.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent r) {
                mousestate = !mousestate;
            }
        });
        JPanel textbar = new JPanel();

        textbar.add(relat);

        JButton set = new JButton();
        set.setText("Set Grid");
        set.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent r) {
                if(row.getValue() != 0 && col.getValue()!= 0){
                    prefs.putInt("row", row.getValue()/4);
                    prefs.putInt("col", col.getValue()/4);
                    length = row.getValue()/4;
                    width = col.getValue()/4;
                    cell = new Cell[length][width];
                    setGrid(panel, cell, row.getValue()/4, col.getValue()/4);
                    shipnum = set_shipnumber(shipnum);
                    Errortable("Success Resize the Grid\n");
                    panel.updateUI();
                }else{
                    Errortable("The col or row can't be 0\n");
                }
            }
        });

        textbar.add(set);

        JButton tex = new JButton();
        tex.setText("Start game");
        tex.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent r) {
                Boolean canstart = Boolean.TRUE;
                if(!connected){
                    Errortable("Not connect, Please Connect\n");
                    return;
                }
                int i; int j;
                for(i = 0; i < shipnum.length; i++){
                    if(shipnum[i] > 0 ){
                        canstart = Boolean.FALSE;
                    }
                }
                if(canstart){
                    setgame = Boolean.FALSE;
                    for(i = 0; i < length; i++){
                        for(j = 0; j < width; j++){
                            cell[i][j].setBackground(Color.BLUE);
                        }
                    }
                }else{
                    Errortable("Still have ship not put in\n");
                }
            }
        });

        textbar.add(tex);
        bar.add(textbar);
        JButton comf = new JButton("Confirm");
        comf.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                path = outputname.getText();
            }
        });
        textbar = new JPanel();

        JLabel ask = new JLabel("Put in the sever id(4-dight)");
        outputname = new JTextField(15);

        textbar.add(ask);
        textbar.add(outputname);
        textbar.add(comf);
        bar.add(textbar);




        JMenuBar menu = new JMenuBar();
        setJMenuBar(menu);

        JMenu file = new JMenu("File");
        menu.add(file);

        JMenuItem showship = new JMenuItem("Show shipdata");
        showship.setAccelerator(KeyStroke.getKeyStroke("ctrl D"));
        file.add(showship);
        showship.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                Errortable(get_shipdata(shipnum));
            }
        });

        JMenuItem getscore = new JMenuItem("Score");
        file.add(getscore);
        getscore.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
               Errortable("The score:"+ Integer.toString(score));
            }
        });

        file.addSeparator();
        JMenuItem exitItem = new JMenuItem("Exit");
        file.add(exitItem);
        exitItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
               System.exit(0);
            }
        });

        JMenu con = new  JMenu("Connect");
        menu.add(con);

        JMenuItem wait = new JMenuItem("Wait");
        wait.setAccelerator(KeyStroke.getKeyStroke("ctrl T"));
        con.add(wait);
        wait.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                connected = Boolean.TRUE;
            }
        });

        JMenuItem tryc = new JMenuItem("Try connect");
        tryc.setAccelerator(KeyStroke.getKeyStroke("ctrl F"));
        con.add(tryc);
        tryc.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent event)
            {
                connected = Boolean.TRUE;
            }
        });

        add(bar, BorderLayout.EAST);

      }

    // a simple Errortable, just jump out and give massage when error occur.
    private void Errortable(String error) 
    {
        JOptionPane.showMessageDialog(null, error +"\n ");
    }


    /**
    * a draw function to draw the gird with given data and refresh the grid  
    * @param cells the 2d array of the cell in a 3d array take the data
    * @param cell the 2d array of the cell need to use to change
    */
    
    public void DrawGrid(Cell[][] cells, Cell[][] cell){
        for(int i = 0; i<cells.length; i++){
            for(int j = 0; j<cells[i].length; j++){
                if(cells[i][j].getboot()){
                    cell[i][j].setBackground(Color.WHITE);
                    cell[i][j].Copycell(cells[i][j]);
                }else{
                    cell[i][j].setBackground(Color.BLUE);
                    cell[i][j].Copycell(cells[i][j]);
                }
            }
        }
    }

    /**
    * a function use to make a JSlider with SnapToTicks and 0 - 25 lableTable 
    * @param bar a JToolBar use to put in the JSlider the function made
    * @param tick The tick with New properties need to be added
    * @param name The name of the slider need to put in the JPanel
    */

    public void getSlider(JToolBar bar, JSlider tick, String name){
        tick.setPaintTicks(true);
        tick.setSnapToTicks(true);
        tick.setPaintLabels(true);
        tick.setMajorTickSpacing(20);
        tick.setMinorTickSpacing(5);

        Dictionary<Integer, Component> labelTable = new Hashtable<Integer, Component>();
        labelTable.put(0, new JLabel("0"));
        labelTable.put(20, new JLabel("5"));
        labelTable.put(40, new JLabel("10"));
        labelTable.put(60, new JLabel("15"));
        labelTable.put(80, new JLabel("20"));
        labelTable.put(100, new JLabel("25"));
        tick.setLabelTable(labelTable);
        JPanel slider = new JPanel();
        slider.add(tick);
        slider.add(new JLabel(name));
        bar.add(slider);
    }

    /**
    * a function use to make a JSlider with SnapToTicks and 0 - 5 lableTable 
    * @param bar a JToolBar use to put in the JSlider the function made
    * @param tick The tick with New properties need to be added
    * @param name The name of the slider need to put in the JPanel
    */

    public void getSlider25(JToolBar bar, JSlider tick, String name){
        tick.setPaintTicks(true);
        tick.setSnapToTicks(true);
        tick.setPaintLabels(true);
        tick.setMajorTickSpacing(20);

        Dictionary<Integer, Component> labelTable = new Hashtable<Integer, Component>();
        labelTable.put(0, new JLabel("0"));
        labelTable.put(20, new JLabel("1"));
        labelTable.put(40, new JLabel("2"));
        labelTable.put(60, new JLabel("3"));
        labelTable.put(80, new JLabel("4"));
        labelTable.put(100, new JLabel("5"));
        tick.setLabelTable(labelTable);
        JPanel slider = new JPanel();
        slider.add(tick);
        slider.add(new JLabel(name));
        bar.add(slider);
    }

    /**
    * a function use to resett the shipdata 
    * @param shipdata The name of the slider need to put in the JPanel
    * @return shipdata, the process useto reset
    */

    public int[] set_shipnumber(int[] shipdata){
        shipdata = new int[10];
        shipdata[0] = 0;
        shipdata[1] = 1;
        shipdata[2] = 2;
        shipdata[3] = 1;
        shipdata[4] = 1;
        return shipdata;
    }

    /**
    * a function use to resett the shipdata 
    * @param shipdata The name of the slider need to put in the JPanel
    */

    public String get_shipdata(int[] shipdata){
        int i;
        String out = "The ship remain to put\n";
        for(i = 0; i< shipdata.length; i++){
            if(shipdata[i]!=0){
                out += "The ship with length "; 
                out += Integer.toString(i+1);
                out += " remain "+ Integer.toString(shipdata[i]);
                out += "\n";
            }
        }
        out += "no other remain ship";
        return out;
    }

    /**
    * the method use to set a clean Grid in window, with row and col given
    * @param test The drawmap, which show on mainwindow
    * @param cell The 2D cell array use to store the cell data for process
    * @param row The number of row of the Grid need to have
    * @param col The number of col of the Grid need to have
    */

    public void setGrid(JPanel test, Cell[][] cell, int row, int col)
    {
        test.removeAll();
        test.setLayout(new GridLayout(row,col));
        for(int i = 0; i<row; i++){
            for(int j = 0; j<col; j++){
                cell[i][j] = new Cell();
                cell[i][j].setCoords(i, j);
                cell[i][j].setBorder(BorderFactory.createLineBorder(Color.WHITE));
                cell[i][j].setBackground(Color.BLUE);
                test.add(cell[i][j]);
                cell[i][j].addMouseListener(handler);
            }
        }
    }

    /**
    * check whether the game is win or not
    * @param cell The 2D cell array use to store the cell data for process
    */

    public Boolean wingame(Cell[][] cell)
    {
        Boolean win = true;
        for(int i = 0; i<length; i++){
            for(int j = 0; j<width; j++){
                if(cell[i][j].getboot()){
                    if(!(cell[i][j].gethit())){
                        win = Boolean.FALSE;
                    }
                }
            }
        }
        return win;
    }




    public static final int DEFAULT_WIDTH = 850;
    public static final int DEFAULT_HEIGHT = 500;
    private int maxtick = 0;
    private JFileChooser chooser;
    private JSlider sizebot;
    private Color cellcolor = Color.WHITE;
    private JTextField outputname;
    private String path = "9999";
    private Preferences prefs = Preferences.userNodeForPackage(src.edu.rpi.cs.csci4963.u20.sunj10.hw03.gol.Running.class);



}