package src.edu.rpi.cs.csci4963.u20.sunj10.hw03.gol;
import javax.swing.JPanel;

/**
* code for homework3
* @author Edward Sun
* @version ％I％，％G％
*/

/**
*Cell is extand of Jpanel, with data
* x,y coor,state and livetime 
*/
public class Cell extends JPanel {
    private int x_coor;
    private int y_coor;
    private Boolean bot;
    private Boolean hit;
    private int boot_id;
    
    
    public Cell(){
        super();
        bot = Boolean.FALSE;
        hit = Boolean.FALSE;
        boot_id = -1;
    }
    
    public void reset_grid(){
        bot = Boolean.FALSE;
        hit = Boolean.FALSE;
    }

    public void setboot(int id){
        bot = Boolean.TRUE;
        boot_id = id;
    }
 
    public int getbotid(){
        return boot_id;
    }

    public Boolean havebotid(){
        return (boot_id > -1);
    }

    public void deletebot(){
        bot = Boolean.FALSE;
        boot_id = -1;
    }

    public Boolean getboot(){
        return bot;
    }

    public Boolean gethit(){
        return hit;
    }
    
    public void Copycell(Cell copy){
        bot = copy.getboot();
        hit = copy.gethit();
        boot_id = copy.getbotid();
        x_coor= copy.getcoorX();
        y_coor= copy.getcoorY();
    }

    public int hitboot(){
        hit = Boolean.TRUE;
        if(bot == Boolean.TRUE){
            bot = Boolean.FALSE;
            return boot_id;
        }
        return -1;
    }

    public void setCoords(int y, int x){
        x_coor=x;
        y_coor=y;
    }
    
    
    //get x_coor
    public int getcoorX(){
        return x_coor;
    }

    //get y_coor
    public int getcoorY(){
        return y_coor;
    }

   
    
}