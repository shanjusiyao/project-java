This program is used to output Bettleship cell survival with swing GUI.

Before that I want to declare that this assignment to complete the degree is not 100%. I have a big cs group project due the same day, and for some reason I have finish that 4 man project all by my self. due time for this two homework is consistent, I spent the past week trying to solve the problem, but still failed to catch up and I had the framework can be used to show, hope you can take into consideration the circumstances give points.
I tried to finish the networking part, but I ran out of time. I saved comments on the code files "BettleApp" I didn't finish, hoping to get some points for the rest.

You can see BettleApp.txt and communicate.txt to see the unfinished part
Thank you.